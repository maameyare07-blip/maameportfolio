# Mohamed Mohamud SH Hassan – Portfolio

This repository hosts the personal portfolio website of Mohamed Mohamud SH Hassan, a Plant Pathologist, Agricultural Researcher, Founder of PathoSolutions, and Seed Inspector at SARIS.

The website showcases:
- About Me
- Education
- Professional Experience
- Research & Projects
- Publications
- Certifications & Workshops
- Skills
- Contact Information

Visit the live site: https://maameportfolio.github.io
